#ifndef TABLES_H
#define TABLES_H

extern int    shine_scale_fact_band_index[9][23];
extern double shine_enwindow[];

#endif

