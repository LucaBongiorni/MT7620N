#ifndef shine_BITSTREAM_H
#define shine_BITSTREAM_H

void shine_bitstream_initialise( shine_global_config *config );

void shine_format_bitstream(shine_global_config *config);

void shine_bitstream_close( shine_global_config *config );

#endif
