#ifndef MAIN_H
#define MAIN_H

void error(char *s);
int  verbose();

#endif
