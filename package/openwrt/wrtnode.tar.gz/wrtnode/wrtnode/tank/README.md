Introduction
===
This is a demo WRTnode send commands to control tank movement by spi1 pin.

The premise is that we want to add driver for spi1 and registration spidev equipment.

