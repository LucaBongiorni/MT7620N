print("Status: 302")
print("Location: /static/apps/index.html")
